﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C5
{
    abstract class Brain
    {
        public List<string> remembered = new List<string>();
        public abstract void Remember();

    }
}
