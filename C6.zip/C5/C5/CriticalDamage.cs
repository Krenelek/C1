﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C5
{
    class CriticalDamage:Damage
    {
        public override int GetPainIndex()
        {
            return d.GetPainIndex() * d.GetPainIndex();
        }
        public override string ToString()
        {
            return d.ToString() + " " + d.ToString();
        }
    }
}
