﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C5
{
    class Erythrocyte: HumanCell
    {
        public override string ToString()
        {
            return "I'm transporting oxygen so you might live!";
        }
    }
}
