﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C5
{
    class Torso
    {

        public List<Limb> limbs= new List<Limb>();
        public Damage GetDamage()
        {

            Random rnd = new Random();
            int i = rnd.Next(limbs.Count());
            limbs[i].t.amountOfCells--;
            Console.WriteLine(" in scale 0-10 it hurts " + limbs[i].GetDamage().GetPainIndex());
            return limbs[i].GetDamage();
        }

    }
}
