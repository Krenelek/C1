﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C5
{
    class CancerCell:HumanCell
    {
        public override string ToString()
        {
            return h.ToString() + " and I will kill him!";
        }
    }
}
