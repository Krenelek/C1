﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C5
{
    class CancerTissue: Tissue
    {

        
        public override HumanCell Grow()
        {
            HumanCell h = t.Grow();
            CancerCell can = new CancerCell();
            can.h = h;
            return can;
        }
    }
}
