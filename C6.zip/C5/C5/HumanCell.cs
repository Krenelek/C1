﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C5
{
    class HumanCell
    {
        public HumanCell h;
        public HumanCell()
        {

        }
        public override string ToString()
        {
            return "I'm part of this hooman!";
        }
    }
}
