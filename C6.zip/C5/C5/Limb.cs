﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C5
{
    abstract class Limb
    {
        public Tissue t = new HealthyTissue();
        public Limb l;
        public abstract Damage GetDamage();
    }
}
