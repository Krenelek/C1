﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C5
{
    class BionicLimb:Limb
    {
        public override Damage GetDamage()
        {
            Damage dmg = new CriticalDamage();
            dmg.d = l.GetDamage();
            return dmg;
        }
    }
}
