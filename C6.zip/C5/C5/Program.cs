﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C5
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            Tissue bm = new BoneMarrow();
            Tissue cancerbone = new CancerTissue();
            cancerbone.t = new BoneMarrow();
            Tissue healthy = new HealthyTissue();
            Tissue cancer = new CancerTissue();
            cancer.t = new HealthyTissue();
            Console.WriteLine(bm.Grow());            
            Console.WriteLine(cancerbone.Grow());
            Console.WriteLine(healthy.Grow());
            Console.WriteLine(cancer.Grow());
            */
            Limb l = new BionicLimb();//dekorator fabryki i udekorowany damage
            l.l = new Leg();
            Console.WriteLine(l.GetDamage());
            Torso t = new Torso();//fasada
            t.limbs.Add(l);
            t.limbs.Add(new Leg());
            Console.WriteLine(t.GetDamage());
            //adapter
            Adapter a = new Adapter();
            a.Remember();
            Console.WriteLine(a.remembered[0]);

        }
    }
}
