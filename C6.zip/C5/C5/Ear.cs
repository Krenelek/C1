﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C5
{
    class Ear
    {
        public string Listen()
        {
            return Console.ReadLine();
        }
    }
}
